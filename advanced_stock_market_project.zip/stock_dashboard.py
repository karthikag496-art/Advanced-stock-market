"""
Advanced Stock Market Analytics & Visualization Dashboard
Dataset: stock_market_data.csv

Install:
    pip install pandas numpy plotly streamlit scikit-learn

Run:
    streamlit run stock_dashboard.py

Note:
The included CSV is illustrative/synthetic data for project development.
For a real-market version, replace the CSV with a properly sourced dataset.
"""

import pandas as pd
import numpy as np
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px

st.set_page_config(page_title="Stock Market Analytics", layout="wide")

@st.cache_data
def load_data():
    df = pd.read_csv("stock_market_data.csv", parse_dates=["Date"])
    return df.sort_values(["Ticker", "Date"])

df = load_data()

st.title("📈 Advanced Stock Market Analytics Dashboard")
st.caption("Historical price, technical-indicator, return and risk analysis")

# Sidebar
st.sidebar.header("Filters")
ticker = st.sidebar.selectbox("Select Stock", sorted(df["Ticker"].unique()))
min_date = df["Date"].min().date()
max_date = df["Date"].max().date()
date_range = st.sidebar.date_input(
    "Date Range", value=(min_date, max_date),
    min_value=min_date, max_value=max_date
)

if len(date_range) == 2:
    start, end = pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1])
else:
    start, end = pd.Timestamp(min_date), pd.Timestamp(max_date)

d = df[(df["Ticker"] == ticker) & (df["Date"].between(start, end))].copy()
d = d.sort_values("Date")

# Technical indicators
d["SMA20"] = d["Close"].rolling(20).mean()
d["SMA50"] = d["Close"].rolling(50).mean()
d["EMA20"] = d["Close"].ewm(span=20, adjust=False).mean()

delta = d["Close"].diff()
gain = delta.clip(lower=0).rolling(14).mean()
loss = (-delta.clip(upper=0)).rolling(14).mean()
rs = gain / loss.replace(0, np.nan)
d["RSI14"] = 100 - (100 / (1 + rs))

ema12 = d["Close"].ewm(span=12, adjust=False).mean()
ema26 = d["Close"].ewm(span=26, adjust=False).mean()
d["MACD"] = ema12 - ema26
d["Signal"] = d["MACD"].ewm(span=9, adjust=False).mean()

rolling_mean = d["Close"].rolling(20).mean()
rolling_std = d["Close"].rolling(20).std()
d["UpperBand"] = rolling_mean + 2 * rolling_std
d["LowerBand"] = rolling_mean - 2 * rolling_std

d["DailyReturn"] = d["Close"].pct_change() * 100

# KPIs
latest = d.iloc[-1]
first_close = d["Close"].iloc[0]
latest_close = latest["Close"]
total_return = ((latest_close / first_close) - 1) * 100
volatility = d["DailyReturn"].std() * np.sqrt(252)
max_drawdown = ((d["Close"] / d["Close"].cummax()) - 1).min() * 100

c1, c2, c3, c4 = st.columns(4)
c1.metric("Latest Close", f"₹{latest_close:,.2f}")
c2.metric("Period Return", f"{total_return:.2f}%")
c3.metric("Annualized Volatility", f"{volatility:.2f}%")
c4.metric("Max Drawdown", f"{max_drawdown:.2f}%")

st.subheader(f"{ticker} — Candlestick & Moving Averages")
fig = go.Figure()
fig.add_trace(go.Candlestick(
    x=d["Date"], open=d["Open"], high=d["High"],
    low=d["Low"], close=d["Close"], name="Price"
))
fig.add_trace(go.Scatter(x=d["Date"], y=d["SMA20"], name="SMA 20"))
fig.add_trace(go.Scatter(x=d["Date"], y=d["SMA50"], name="SMA 50"))
fig.add_trace(go.Scatter(x=d["Date"], y=d["EMA20"], name="EMA 20"))
fig.update_layout(xaxis_rangeslider_visible=False, height=600)
st.plotly_chart(fig, use_container_width=True)

col1, col2 = st.columns(2)

with col1:
    st.subheader("RSI (14)")
    rsi_fig = go.Figure()
    rsi_fig.add_trace(go.Scatter(x=d["Date"], y=d["RSI14"], name="RSI"))
    rsi_fig.add_hline(y=70, line_dash="dash")
    rsi_fig.add_hline(y=30, line_dash="dash")
    rsi_fig.update_yaxes(range=[0, 100])
    st.plotly_chart(rsi_fig, use_container_width=True)

with col2:
    st.subheader("MACD")
    macd_fig = go.Figure()
    macd_fig.add_trace(go.Scatter(x=d["Date"], y=d["MACD"], name="MACD"))
    macd_fig.add_trace(go.Scatter(x=d["Date"], y=d["Signal"], name="Signal"))
    st.plotly_chart(macd_fig, use_container_width=True)

st.subheader("Bollinger Bands")
bb = go.Figure()
bb.add_trace(go.Scatter(x=d["Date"], y=d["UpperBand"], name="Upper Band"))
bb.add_trace(go.Scatter(x=d["Date"], y=d["Close"], name="Close"))
bb.add_trace(go.Scatter(x=d["Date"], y=d["LowerBand"], name="Lower Band"))
bb.update_layout(height=450)
st.plotly_chart(bb, use_container_width=True)

st.subheader("Trading Volume")
vol = px.bar(d, x="Date", y="Volume", title=f"{ticker} Trading Volume")
vol.update_layout(height=400)
st.plotly_chart(vol, use_container_width=True)

st.subheader("Risk–Return Comparison")
summary = []
for t in sorted(df["Ticker"].unique()):
    x = df[df["Ticker"] == t].sort_values("Date").copy()
    x["Return"] = x["Close"].pct_change()
    annual_return = x["Return"].mean() * 252 * 100
    annual_vol = x["Return"].std() * np.sqrt(252) * 100
    summary.append([t, annual_return, annual_vol])

risk_df = pd.DataFrame(summary, columns=["Ticker", "Annual Return (%)", "Volatility (%)"])
risk_fig = px.scatter(
    risk_df, x="Volatility (%)", y="Annual Return (%)",
    text="Ticker", size="Volatility (%)",
    title="Annualized Risk vs Return"
)
risk_fig.update_traces(textposition="top center")
st.plotly_chart(risk_fig, use_container_width=True)

st.subheader("Recent Data")
st.dataframe(d.tail(20), use_container_width=True)

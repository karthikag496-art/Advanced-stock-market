# Advanced Stock Market Analytics & Visualization

## Files
- stock_market_data.csv — illustrative/synthetic stock dataset
- stock_dashboard.py — Streamlit dashboard
- requirements.txt — required Python packages

## Run
1. Open terminal in this folder.
2. Run: `pip install -r requirements.txt`
3. Run: `streamlit run stock_dashboard.py`

## Features
- Candlestick chart
- SMA 20 / SMA 50
- EMA 20
- RSI 14
- MACD + Signal
- Bollinger Bands
- Trading volume
- Period return
- Annualized volatility
- Maximum drawdown
- Risk-return comparison
- Interactive stock/date filters

Important: The included CSV is synthetic/illustrative, not real market data.
